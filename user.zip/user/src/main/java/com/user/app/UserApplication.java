package com.user.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages={"com.user"})
public class UserApplication {

	public static void main(String[] args) {
		System.out.println("Entering intohere");
		SpringApplication.run(UserApplication.class, args);
	}
}
