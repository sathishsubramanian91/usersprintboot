package com.user.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.user.domain.User;
import com.user.domain.UserResponse;
import com.user.service.UserSVC;


@Component
@RestController
@RequestMapping(value="/user")
public class UserEPImpl  
{
	
   
	@Autowired
	UserSVC userSVC;

	/*@Override
	
	public UserResponse createUser(User user) {
		
		return userSVC.createUser(user);
		
	}

	@Override
	public UserResponse updateUser(String userId, User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserResponse deleteUser(String userId) {
		
		return null;
	}*/

	
	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String getUser() {
	
		
		return "Welcome Message";
	}
 
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public UserResponse createUser(@RequestBody User user) {
			
			return userSVC.createUser(user);
			
		}



}
