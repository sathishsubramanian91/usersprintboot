package com.user.repo;

import org.springframework.data.repository.Repository;

import com.user.domain.User;


public interface UserRepo extends Repository<User, String>{
	

	

}
