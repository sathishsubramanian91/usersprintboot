package com.user.service;

import java.util.Date;

import com.user.domain.User;
import com.user.domain.UserResponse;

public interface UserSVC {
	
	public UserResponse createUser(User user);
	public UserResponse updateUser(String id,String pinCode,Date birthdDate);
	public UserResponse deleteUser(String id);

}
