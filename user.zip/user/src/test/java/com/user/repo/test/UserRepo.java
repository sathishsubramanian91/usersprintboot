package com.user.repo.test;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.user.app.UserApplication;
import com.user.domain.User;

import com.user.repo.UserRepositoryImpl;

import junit.framework.Assert;

@RunWith(value = SpringRunner.class)
@SpringBootTest(classes = { UserApplication.class })
public class UserRepo {

	@Autowired
	UserRepositoryImpl userRepo;
	
	
	@Test
	public void test() {
	//setup the test data
	User expectedUser=new User();
	User actualUser=null; 
	expectedUser.setId("E1001");
	expectedUser.setfName("sathish");
	expectedUser.setlName("subramanian");
	expectedUser.setBirthDate(new Date());
	expectedUser.setActive(true);
	expectedUser.setEmail("sss@gmail.com");

	userRepo.save(expectedUser);
	
	userRepo.delete(expectedUser.getId());
	
	
	actualUser = userRepo.find(expectedUser.getId());
	
	Assert.assertEquals(actualUser.getId(), expectedUser.getId());
	
	Assert.assertEquals(actualUser.isActive(),false );
	
		
	}

}
