package com.user.service;

public class UserSVCImpl implements UserSVC {

}
