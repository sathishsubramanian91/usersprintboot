package com.user.service;

public interface UserSVC {

}
