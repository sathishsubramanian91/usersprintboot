package com.user.endpoint;

import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import org.springframework.web.bind.annotation.RequestBody;

import com.user.domain.User;
import com.user.domain.UserResponse;

@Path("/users")
public interface UserEP {

	@POST
	@Path("/create")
	public UserResponse createUser(@RequestBody User user);
	
    @PUT
    @Path("/update")
    public UserResponse updateUser(@QueryParam("id") String userId,@RequestBody User user);
    
	
	@DELETE
    @Path("/delete")
    public UserResponse deleteUser(@QueryParam("id") String userId);
    
    
	
}
