package com.user.endpoint;

import com.user.domain.User;
import com.user.domain.UserResponse;

public class UserEPImpl implements UserEP {

	@Override
	public UserResponse createUser(User user) {
		
		
		return null;
	}

	@Override
	public UserResponse updateUser(String userId, User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserResponse deleteUser(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
