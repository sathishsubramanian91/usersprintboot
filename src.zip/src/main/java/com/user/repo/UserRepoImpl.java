package com.user.repo;

public class UserRepoImpl implements UserRepo {

}
