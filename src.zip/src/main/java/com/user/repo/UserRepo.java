package com.user.repo;

public interface UserRepo {

}
